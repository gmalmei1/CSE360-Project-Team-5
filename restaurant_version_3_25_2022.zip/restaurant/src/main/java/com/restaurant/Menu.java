package com.restaurant;

import javafx.scene.image.Image;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Locale;

class DefaultComparator implements Comparator<MenuItem>{

    @Override
    public int compare(MenuItem item1, MenuItem item2) {

        //if the first price is less than the second, first comes before second
        if (item1.getItemNum() < item2.getItemNum()){
            return -1;
        }
        //if the prices are equal, return 0
        else if (item1.getItemNum() == item2.getItemNum()){
            return 0;
        }
        //if the first price is more than the second, first comes after second
        return 1;
    }
}

class LowToHighPriceComparator implements Comparator<MenuItem>{

    @Override
    public int compare(MenuItem item1, MenuItem item2) {

        //if the first price is less than the second, first comes before second
        if (item1.getPrice() < item2.getPrice()){
            return -1;
        }
        //if the prices are equal, return 0
        else if (item1.getPrice() == item2.getPrice()){
            return 0;
        }
        //if the first price is more than the second, first comes after second
        return 1;
    }
}

class HighToLowPriceComparator implements Comparator<MenuItem>{

    @Override
    public int compare(MenuItem item1, MenuItem item2) {

        //if the first price is more than the second, first comes before second
        if (item1.getPrice() > item2.getPrice()){
            return -1;
        }
        //if the prices are equal, return 0
        else if (item1.getPrice() == item2.getPrice()){
            return 0;
        }
        //if the first price is less than the second, first comes after second
        return 1;
    }
}

class AlphabeticalComparator implements Comparator<MenuItem>{

    @Override
    public int compare(MenuItem item1, MenuItem item2) {
        // if the first name is lexicographically lower than the second, first comes before second
        if (item1.getName().compareTo(item2.getName()) < 0){
            return -1;
        }
        // if the first name is lexicographically higher than the second, first comes after second
        else if (item1.getName().compareTo(item2.getName()) > 0){
            return 1;
        }
        // otherwise, the names are equivalent
        else {
            return 0;
        }
    }
}

class ReverseAlphabeticalComparator implements Comparator<MenuItem>{

    @Override
    public int compare(MenuItem item1, MenuItem item2) {
        // if the first name is lexicographically higher than the second, place first before second
        if (item1.getName().compareTo(item2.getName()) > 0){
            return -1;
        }
        // if the first name is lexicographically lower than the second, place first after second
        else if (item1.getName().compareTo(item2.getName()) < 0){
            return 1;
        }
        // otherwise, the names are equivalent, no need to swap
        else {
            return 0;
        }
    }
}



public class Menu {

    public ArrayList<MenuItem> items;
    public int menuSize;
    public int itemMin;

    public int matches;

    public ArrayList<MenuItem> items_match;
    public ArrayList<MenuItem> items_notmatch;

    public ArrayList<String> types;
    public ArrayList<String> allergens;

    //create empty menu w/ specific types and allergens
    public Menu(ArrayList<String> types, ArrayList<String> allergens){
        items = new ArrayList<>();
        menuSize = 0;
        itemMin = 5;

        matches = 0;

        items_match = new ArrayList<>();
        items_notmatch = new ArrayList<>();

        this.types = types;
        this.allergens = allergens;
    }

    public void printItems(){
        System.out.println("Menu:");
        for (MenuItem m : items){
            System.out.println(m.getItemNum() + ": " + m.getName());
        }
        System.out.println("");
    }


    //function called if Admin adds to menu: create item from parameters
    // and add it to the menu, increase menu item count

    public void addToMenu(String name, double price, String type, String description, int timeToMake, Image picture){
        items.add(new MenuItem(menuSize + 1, name, price, type, description, timeToMake, picture));
        menuSize++;
    }

    // function called if Admin removes item in menu by name: search for items
    // that have the same name as the name given and if there is a match,
    // then remove that from the list

    public void removeFromMenu(String name){
        if (items.removeIf(menuItem -> name.equalsIgnoreCase(menuItem.getName()))){
            menuSize--;
        }
    }

    // given a valid search query, find all menu items that contain the query and add
    // them to the top of the items arrayList (items that don't match are shown below the matches)
    // also, update the matches count to reflect how many results the search obtained

    public ArrayList<MenuItem> searchByQuery(String query){
        query = query.toLowerCase();
        items_match = new ArrayList<>();
        items_notmatch = new ArrayList<>();
        if (items.size() == 0) { return null; }
        for (MenuItem m : items){
            if (m.getName().toLowerCase().contains(query) || m.getDescription().toLowerCase().contains(query)){
                items_match.add(m);
            }
            else {
                items_notmatch.add(m);
            }
        }
        matches = items_match.size();
        items_match.addAll(items_notmatch);
        return items_match;
    }

    // sort by price takes in the boolean lowFirst where it sorts the menu items from
    // lowest to highest price if true (highest to the lowest if false)
    // sort using the custom comparators in the arrayList.sort function

    public ArrayList<MenuItem> sortByPrice(boolean lowFirst) {
        matches = 0;
        items_match = items;
        if (lowFirst){
            items_match.sort(new LowToHighPriceComparator());
        }
        else {
            items_match.sort(new HighToLowPriceComparator());
        }
        return items_match;
    }

    // sort by alphabetical order takes in the boolean reverse where it sorts the menu items from
    // A-Z if false (Z-A if true)
    // sort using the custom comparators in the arrayList.sort function

    public ArrayList<MenuItem> sortAlphabetically(boolean reverse) {
        matches = 0;
        items_match = items;
        if (reverse){
            items_match.sort(new ReverseAlphabeticalComparator());
        }
        else {
            items_match.sort(new AlphabeticalComparator());
        }
        return items_match;
    }

    // sort by default reorganizes the menu items into the original order in which
    // they were added into the menu
    // sort using the custom comparators in the arrayList.sort function

    public ArrayList<MenuItem> sortByDefault() {
        matches = 0;
        items_match = items;
        items_match.sort(new DefaultComparator());
        return items_match;
    }
}
